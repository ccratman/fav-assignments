package edu.wcc.cps278.finalproject278.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import edu.wcc.cps278.finalproject278.model.Customer;
import edu.wcc.cps278.finalproject278.service.*;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {

    private final CheckoutService checkoutService = new CheckoutService();
    private final CustomerService customerService = new CustomerService();

    // =========================
    // RESOLVE CUSTOMER
    // =========================
    private Integer resolveCustomer(HttpSession session) {

        Integer cid = (Integer) session.getAttribute("customerId");

        if (cid == null) {
            cid = 1;
            session.setAttribute("customerId", cid);
        }

        return cid;
    }

    // =========================
    // HOME
    // =========================
    @GetMapping("/")
    public String home(@RequestParam(required = false) Integer customerId,
                       HttpSession session,
                       Model model) {

        if (customerId != null) {
            session.setAttribute("customerId", customerId);
        }

        Integer cid = resolveCustomer(session);

        Customer currentCustomer = customerService.getById(cid);

        model.addAttribute("customers", customerService.getAll());
        model.addAttribute("currentCustomer", currentCustomer);

        return "index";
    }

    // =========================
    // CHECKOUT
    // =========================
    @PostMapping("/checkout")
    public String checkout(@RequestParam int movieId,
                           HttpSession session) {

        Integer customerId = resolveCustomer(session);

        checkoutService.checkoutSafe(customerId, movieId);

        return "redirect:/movies";
    }

    // =========================
    // RETURN
    // =========================
    @PostMapping("/return")
    public String returnMovie(@RequestParam int checkoutId,
                              HttpSession session) {

        resolveCustomer(session);

        checkoutService.returnMovie(checkoutId);

        return "redirect:/history";
    }

    // =========================
    // HISTORY
    // =========================
    @GetMapping("/history")
    public String history(HttpSession session, Model model) {

        Integer customerId = resolveCustomer(session);

        model.addAttribute("history",
                checkoutService.getHistory(customerId));

        model.addAttribute("currentCustomer",
                customerService.getById(customerId));

        return "history";
    }
}