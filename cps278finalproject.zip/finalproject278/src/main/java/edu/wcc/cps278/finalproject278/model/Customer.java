package edu.wcc.cps278.finalproject278.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    private String email; 

    @OneToMany(mappedBy = "customer")
    private List<Checkout> checkouts;

    // =========================
    // GETTERS / SETTERS
    // =========================

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; } // ✅ ADD
    public void setEmail(String email) { this.email = email; } // ✅ ADD

    public List<Checkout> getCheckouts() { return checkouts; }
    public void setCheckouts(List<Checkout> checkouts) { this.checkouts = checkouts; }
}