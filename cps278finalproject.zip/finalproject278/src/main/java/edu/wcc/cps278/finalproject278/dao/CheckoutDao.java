package edu.wcc.cps278.finalproject278.dao;

import edu.wcc.cps278.finalproject278.model.Checkout;
import edu.wcc.cps278.finalproject278.model.Movie;
import edu.wcc.cps278.finalproject278.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Date;
import java.util.List;

public class CheckoutDao {

    // =========================
    // SAVE CHECKOUT
    // =========================
    public void save(Checkout checkout) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            session.save(checkout);

            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace(); // safe for dev + assignment
        } finally {
            session.close();
        }
    }

    // =========================
    // GET HISTORY
    // =========================
    public List<Checkout> getByCustomer(int customerId) {

        Session session = HibernateUtil.getSessionFactory().openSession();

        List<Checkout> list = session.createQuery(
                        "from Checkout where customer.id = :cid",
                        Checkout.class)
                .setParameter("cid", customerId)
                .list();

        session.close();
        return list;
    }

    // =========================
    // RETURN MOVIE
    // =========================
    public void returnMovie(int checkoutId) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            Checkout checkout = session.get(Checkout.class, checkoutId);

            if (checkout != null && !checkout.isReturned()) {

                Movie movie = checkout.getMovie();
                movie.setAvailableCopies(movie.getAvailableCopies() + 1);

                checkout.setReturned(true);
                checkout.setReturnDate(new Date());

                session.update(movie);
                session.update(checkout);
            }

            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace(); // safe fallback
        } finally {
            session.close();
        }
    }
}