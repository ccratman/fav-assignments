package edu.wcc.cps278.finalproject278.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String description;
    private int availableCopies;

    // =========================
    // NEW FIELDS (FIXED FOR HIBERNATE NULL SAFETY)
    // =========================

    private Integer year;          // was int ❌
    private String genre;

    private Integer duration;      // was int ❌ (THIS WAS YOUR CRASH)

    private String rating;        // PG / PG-13 / R

    private Double criticRating;  // was double ❌

    @OneToMany(mappedBy = "movie")
    private List<Checkout> checkouts;

    // =========================
    // GETTERS / SETTERS
    // =========================

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) { this.availableCopies = availableCopies; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }

    public String getRating() { return rating; }
    public void setRating(String rating) { this.rating = rating; }

    public Double getCriticRating() { return criticRating; }
    public void setCriticRating(Double criticRating) { this.criticRating = criticRating; }

    public List<Checkout> getCheckouts() { return checkouts; }
    public void setCheckouts(List<Checkout> checkouts) { this.checkouts = checkouts; }
}