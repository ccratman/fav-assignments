package edu.wcc.cps278.finalproject278.service;

import edu.wcc.cps278.finalproject278.model.Checkout;
import edu.wcc.cps278.finalproject278.model.Customer;
import edu.wcc.cps278.finalproject278.model.Movie;
import edu.wcc.cps278.finalproject278.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Date;
import java.util.List;

public class CheckoutService {

    // =========================
    // CHECKOUT MOVIE
    // =========================
    public void checkoutSafe(int customerId, int movieId) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Customer customer = session.get(Customer.class, customerId);
        Movie movie = session.get(Movie.class, movieId);

        if (movie == null || customer == null) {
            tx.commit();
            session.close();
            return;
        }

        // ONLY RULE: inventory must exist
        if (movie.getAvailableCopies() <= 0) {
            tx.commit();
            session.close();
            return;
        }

        // NO DUPLICATE CHECK (this is what was blocking you)

        movie.setAvailableCopies(movie.getAvailableCopies() - 1);

        Checkout c = new Checkout();
        c.setCustomer(customer);
        c.setMovie(movie);
        c.setCheckoutDate(new Date());
        c.setReturned(false);

        session.save(c);
        session.update(movie);

        tx.commit();
        session.close();
    }

    // =========================
    // RETURN MOVIE
    // =========================
    public void returnMovie(int checkoutId) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Checkout c = session.get(Checkout.class, checkoutId);

        if (c != null && !c.isReturned()) {

            c.setReturned(true);
            c.setReturnDate(new Date());

            Movie movie = c.getMovie();
            movie.setAvailableCopies(movie.getAvailableCopies() + 1);

            session.update(c);
            session.update(movie);
        }

        tx.commit();
        session.close();
    }

    // =========================
    // HISTORY
    // =========================
    public List<Checkout> getHistory(int customerId) {

        Session session = HibernateUtil.getSessionFactory().openSession();

        List<Checkout> list = session.createQuery(
                "from Checkout where customer.id = :cid",
                Checkout.class
        )
        .setParameter("cid", customerId)
        .list();

        session.close();
        return list;
    }
}