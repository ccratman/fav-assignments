package edu.wcc.cps278.finalproject278.dao;

import edu.wcc.cps278.finalproject278.model.Customer;
import edu.wcc.cps278.finalproject278.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class CustomerDao {

    public List<Customer> getAll() {

        Session session = HibernateUtil.getSessionFactory().openSession();

        List<Customer> list = session.createQuery(
                "from Customer",
                Customer.class
        ).list();

        session.close();
        return list;
    }

    public Customer getById(int id) {

        Session session = HibernateUtil.getSessionFactory().openSession();

        Customer customer = session.get(Customer.class, id);

        session.close();
        return customer;
    }

    public void save(Customer customer) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.save(customer);
            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace(); // important fix
        } finally {
            session.close();
        }
    }

    public void update(Customer customer) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.update(customer);
            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace(); // important fix
        } finally {
            session.close();
        }
    }

    public void delete(int id) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            Customer customer = session.get(Customer.class, id);

            if (customer != null) {
                session.delete(customer);
            }

            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace(); // important fix
        } finally {
            session.close();
        }
    }
}