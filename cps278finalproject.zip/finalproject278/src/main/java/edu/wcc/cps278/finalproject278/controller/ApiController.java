package edu.wcc.cps278.finalproject278.controller;

import org.springframework.web.bind.annotation.*;

import edu.wcc.cps278.finalproject278.service.*;
import edu.wcc.cps278.finalproject278.model.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ApiController {

    private MovieService movieService = new MovieService();
    private CheckoutService checkoutService = new CheckoutService();

    @GetMapping("/movie")
    public List<Movie> searchMovie(@RequestParam String title) {
        return movieService.search(title);
    }

    @GetMapping("/history")
    public List<Checkout> history(@RequestParam int customerId) {
        return checkoutService.getHistory(customerId);
    }
}