package edu.wcc.cps278.finalproject278.controller;

import edu.wcc.cps278.finalproject278.model.Customer;
import edu.wcc.cps278.finalproject278.service.CustomerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CustomerController {

    private final CustomerService customerService = new CustomerService();

    // =========================
    // VIEW CUSTOMERS PAGE
    // =========================
    @GetMapping("/customers")
    public String customers(Model model) {

        model.addAttribute("customers", customerService.getAll());
        return "customers";
    }

    // =========================
    // ADD CUSTOMER
    // =========================
    @PostMapping("/addCustomer")
    public String addCustomer(@RequestParam String name,
                              @RequestParam String email,
                              Model model) {

        name = name.trim();
        email = email.trim().toLowerCase();

        model.addAttribute("customers", customerService.getAll());
        model.addAttribute("nameValue", name);
        model.addAttribute("emailValue", email);

        // =========================
        // NAME VALIDATION
        // =========================
        if (name == null || !name.matches("^[A-Za-z ]{2,50}$")) {
            model.addAttribute("error", "Please enter a valid name (letters only)");
            return "customers";
        }

        // =========================
        // EMAIL VALIDATION (Gmail only)
        // =========================
        if (!email.matches("^[A-Za-z0-9._%+-]+@gmail\\.com$")) {
            model.addAttribute("error", "Please enter a valid Gmail address");
            return "customers";
        }

        // =========================
        // DUPLICATE EMAIL CHECK
        // =========================
        if (customerService.emailExists(email)) {
            model.addAttribute("error", "This email is already registered");
            return "customers";
        }

        // SAVE
        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);

        customerService.save(customer);

        return "redirect:/customers";
    }

    // =========================
    // DELETE CUSTOMER
    // =========================
    @PostMapping("/deleteCustomer")
    public String deleteCustomer(@RequestParam int id) {

        customerService.delete(id);
        return "redirect:/customers";
    }

    // =========================
    // UPDATE CUSTOMER
    // =========================
    @PostMapping("/updateCustomer")
    public String updateCustomer(@RequestParam int id,
                                 @RequestParam String name,
                                 @RequestParam String email,
                                 Model model) {

        name = name.trim();
        email = email.trim().toLowerCase();

        model.addAttribute("customers", customerService.getAll());

        // =========================
        // NAME VALIDATION
        // =========================
        if (name == null || !name.matches("^[A-Za-z ]{2,50}$")) {
            model.addAttribute("error", "Please enter a valid name (letters only)");
            return "customers";
        }

        // =========================
        // EMAIL VALIDATION
        // =========================
        if (!email.matches("^[A-Za-z0-9._%+-]+@gmail\\.com$")) {
            model.addAttribute("error", "Please enter a valid Gmail address");
            return "customers";
        }

        // =========================
        // DUPLICATE CHECK (ignore self)
        // =========================
        if (customerService.emailExistsForUpdate(id, email)) {
            model.addAttribute("error", "This email is already in use");
            return "customers";
        }

        // UPDATE
        Customer customer = new Customer();
        customer.setId(id);
        customer.setName(name);
        customer.setEmail(email);

        customerService.update(customer);

        return "redirect:/customers";
    }
}