package edu.wcc.cps278.finalproject278.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import edu.wcc.cps278.finalproject278.model.*;

public class HibernateUtil {

    private static final SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Customer.class)
            .addAnnotatedClass(Movie.class)
            .addAnnotatedClass(Checkout.class)
            .buildSessionFactory();

    public static SessionFactory getSessionFactory() {
        return factory;
    }
}