package edu.wcc.cps278.finalproject278.service;

import edu.wcc.cps278.finalproject278.dao.MovieDao;
import edu.wcc.cps278.finalproject278.model.Movie;

import java.util.List;

public class MovieService {

    private final MovieDao dao = new MovieDao();

    public List<Movie> getAllMovies() {
        return dao.getAllMovies();
    }

    public Movie getById(int id) {
        return dao.getById(id);
    }

    public List<Movie> search(String keyword) {
        return dao.search(keyword);
    }

    public void addMovie(Movie movie) {
        dao.save(movie);
    }

    public void updateMovie(Movie movie) {
        dao.update(movie);
    }

    public void deleteMovie(int id) {
        dao.delete(id);
    }
}