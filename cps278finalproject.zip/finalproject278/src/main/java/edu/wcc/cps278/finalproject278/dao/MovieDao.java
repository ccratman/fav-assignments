package edu.wcc.cps278.finalproject278.dao;

import edu.wcc.cps278.finalproject278.model.Movie;
import edu.wcc.cps278.finalproject278.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class MovieDao {

    public List<Movie> getAllMovies() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Movie> list = session.createQuery("from Movie", Movie.class).list();
        session.close();
        return list;
    }

    // ✅ FIXED: proper single fetch
    public Movie getById(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Movie movie = session.get(Movie.class, id);
        session.close();
        return movie;
    }

    public void save(Movie movie) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(movie);
        tx.commit();
        session.close();
    }

    public void update(Movie movie) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.update(movie);
        tx.commit();
        session.close();
    }

    public void delete(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Movie movie = session.get(Movie.class, id);
        if (movie != null) {
            session.delete(movie);
        }

        tx.commit();
        session.close();
    }

    public List<Movie> search(String keyword) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Movie> list = session.createQuery(
                "from Movie where title like :k or description like :k",
                Movie.class)
                .setParameter("k", "%" + keyword + "%")
                .list();

        session.close();
        return list;
    }
}