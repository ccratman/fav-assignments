package edu.wcc.cps278.finalproject278.service;

import edu.wcc.cps278.finalproject278.dao.CustomerDao;
import edu.wcc.cps278.finalproject278.model.Customer;

import java.util.List;

public class CustomerService {

    private final CustomerDao dao = new CustomerDao();

    public List<Customer> getAll() {
        return dao.getAll();
    }

    public Customer getById(int id) {
        return dao.getById(id);
    }

    public void save(Customer customer) {
        dao.save(customer);
    }

    public void update(Customer customer) {
        dao.update(customer);
    }

    public void delete(int id) {
        dao.delete(id);
    }

    // =========================
    // SAFE EMAIL CHECK (NO LAMBDA)
    // =========================
    public boolean emailExists(String email) {

        if (email == null) return false;

        List<Customer> customers = getAll();

        for (Customer c : customers) {
            if (c.getEmail() != null &&
                c.getEmail().equalsIgnoreCase(email)) {
                return true;
            }
        }

        return false;
    }

    // =========================
    // SAFE UPDATE EMAIL CHECK
    // =========================
    public boolean emailExistsForUpdate(int id, String email) {

        if (email == null) return false;

        List<Customer> customers = getAll();

        for (Customer c : customers) {
            if (c.getEmail() != null &&
                c.getEmail().equalsIgnoreCase(email) &&
                c.getId() != id) {
                return true;
            }
        }

        return false;
    }
}