package edu.wcc.cps278.finalproject278.controller;

import edu.wcc.cps278.finalproject278.model.Customer;
import edu.wcc.cps278.finalproject278.model.Movie;
import edu.wcc.cps278.finalproject278.service.CustomerService;
import edu.wcc.cps278.finalproject278.service.MovieService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
public class MovieController {

    private final MovieService service = new MovieService();
    private final CustomerService customerService = new CustomerService();

    // =========================
    // MOVIES PAGE
    // =========================
    @GetMapping("/movies")
    public String getMovies(HttpSession session, Model model) {

        Integer cid = (Integer) session.getAttribute("customerId");

        if (cid == null) {
            cid = 1;
            session.setAttribute("customerId", cid);
        }

        Customer currentCustomer = customerService.getById(cid);

        model.addAttribute("movies", service.getAllMovies());
        model.addAttribute("currentCustomer", currentCustomer);

        return "movies";
    }

    // =========================
    // SEARCH
    // =========================
    @GetMapping("/movies/search")
    public String search(@RequestParam String keyword,
                         HttpSession session,
                         Model model) {

        Integer cid = (Integer) session.getAttribute("customerId");
        if (cid == null) cid = 1;

        model.addAttribute("movies", service.search(keyword));
        model.addAttribute("currentCustomer", customerService.getById(cid));

        return "movies";
    }

    // =========================
    // ADD MOVIE (STRICT)
    // =========================
    @PostMapping("/addMovie")
    public String addMovie(
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam Integer copies,
            @RequestParam Integer year,
            @RequestParam(required = false) String[] genre,
            @RequestParam(required = false) String hours,
            @RequestParam(required = false) String minutes,
            @RequestParam String rating,
            @RequestParam String criticRating,
            Model model
    ) {

        if (genre == null) genre = new String[]{};

        int h = parseIntSafe(hours);
        int m = parseIntSafe(minutes);

        double critic;
        try {
            critic = Double.parseDouble(criticRating);
        } catch (Exception e) {
            model.addAttribute("error", "Invalid critic rating");
            model.addAttribute("movies", service.getAllMovies());
            return "movies";
        }

        // ADD RULE: copies MUST be >= 1
        if (copies == null || copies < 1) {
            model.addAttribute("error", "Copies must be at least 1 when adding a movie");
            model.addAttribute("movies", service.getAllMovies());
            return "movies";
        }

        if (critic < 1 || critic > 5) {
            model.addAttribute("error", "CRITIC RATING MUST BE 1–5");
            model.addAttribute("movies", service.getAllMovies());
            return "movies";
        }

        Movie movie = new Movie();
        movie.setTitle(title);
        movie.setDescription(description);
        movie.setAvailableCopies(copies);
        movie.setYear(year);
        movie.setGenre(String.join(",", genre));
        movie.setDuration((h * 60) + m);
        movie.setRating(rating);
        movie.setCriticRating(critic);

        service.addMovie(movie);

        return "redirect:/movies";
    }

    // =========================
    // EDIT PAGE
    // =========================
    @GetMapping("/editMoviePage")
    public String editMoviePage(@RequestParam int id, Model model) {
        model.addAttribute("movie", service.getById(id));
        return "editMovie";
    }

    // =========================
    // EDIT MOVIE (ALLOW 0 COPIES + SAFE PARSE)
    // =========================
    @PostMapping("/editMovie")
    public String editMovie(
            @RequestParam int id,
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam Integer copies,
            @RequestParam Integer year,
            @RequestParam(required = false) String[] genre,
            @RequestParam(required = false) String hours,
            @RequestParam(required = false) String minutes,
            @RequestParam String rating,
            @RequestParam String criticRating,
            Model model
    ) {

        Movie movie = service.getById(id);
        if (movie == null) return "redirect:/movies";

        if (genre == null) genre = new String[]{};

        int h = parseIntSafe(hours);
        int m = parseIntSafe(minutes);

        double critic;
        try {
            critic = Double.parseDouble(criticRating);
        } catch (Exception e) {
            model.addAttribute("error", "Invalid critic rating");
            model.addAttribute("movie", movie);
            return "editMovie";
        }

        if (critic < 1 || critic > 5) {
            model.addAttribute("error", "CRITIC RATING MUST BE 1–5");
            model.addAttribute("movie", movie);
            return "editMovie";
        }

        movie.setTitle(title);
        movie.setDescription(description);
        movie.setAvailableCopies(copies); // ALLOWS 0
        movie.setYear(year);
        movie.setGenre(String.join(",", genre));
        movie.setDuration((h * 60) + m);
        movie.setRating(rating);
        movie.setCriticRating(critic);

        service.updateMovie(movie);

        return "redirect:/movies";
    }

    // =========================
    // DELETE
    // =========================
    @PostMapping("/deleteMovie")
    public String deleteMovie(@RequestParam int id) {
        service.deleteMovie(id);
        return "redirect:/movies";
    }

    // =========================
    // SAFE PARSER
    // =========================
    private int parseIntSafe(String val) {
        try {
            return (val == null || val.isEmpty()) ? 0 : Integer.parseInt(val);
        } catch (Exception e) {
            return 0;
        }
    }
}