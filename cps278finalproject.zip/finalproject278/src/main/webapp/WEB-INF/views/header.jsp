<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    .navbar {
        background: linear-gradient(90deg, #1e1e2f, #2c2c54);
    }

    .nav-btn {
        border-radius: 20px;
        padding: 5px 12px;
        transition: 0.2s;
    }

    .nav-btn:hover {
        background-color: rgba(255,255,255,0.15);
    }

    .brand-glow {
        letter-spacing: 0.5px;
    }

    .user-badge {
        background: rgba(255,255,255,0.15);
        border-radius: 20px;
        padding: 6px 12px;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm px-4">

    <!-- BRAND -->
    <a class="navbar-brand fw-bold brand-glow" href="/finalproject278/">
        🎬 Movie System
    </a>

    <!-- RIGHT SIDE -->
    <div class="ms-auto d-flex align-items-center gap-3">

        <!-- ACTIVE USER -->
        <div class="user-badge text-white small">
            👤
            <c:choose>
                <c:when test="${not empty currentCustomer}">
                    ${currentCustomer.name}
                </c:when>
                <c:otherwise>Guest</c:otherwise>
            </c:choose>
        </div>

        <!-- NAV LINKS -->
        <a class="btn btn-sm nav-btn text-white" href="/finalproject278/">
            🏠 Home
        </a>

        <a class="btn btn-sm nav-btn text-white" href="/finalproject278/movies">
            🎬 Movies
        </a>

        <a class="btn btn-sm nav-btn text-white" href="/finalproject278/history">
            📜 History
        </a>

        <a class="btn btn-sm nav-btn text-white" href="/finalproject278/customers">
            👤 Customers
        </a>

    </div>

</nav>