<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="header.jsp" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<style>
.movie-card {
    border-radius: 16px;
    transition: 0.2s;
}

.movie-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 28px rgba(0,0,0,0.1);
}

.movie-title { font-weight: 600; font-size: 1.05rem; }
.movie-desc { font-size: 0.9rem; color: #6c757d; min-height: 40px; }

.meta { font-size: 0.75rem; color: #6c757d; }

.star-bar { color: gold; }

.badge-soft {
    font-size: 0.75rem;
    padding: 6px 10px;
    border-radius: 12px;
}
</style>

<div class="container mt-4">

<!-- ERROR DISPLAY -->
<c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
</c:if>

<!-- ADD MOVIE -->
<div class="card p-4 mb-4 shadow-sm border-0">

<h5 class="mb-3">Add Movie</h5>

<form action="/finalproject278/addMovie" method="post" class="row g-3">

    <div class="col-md-3">
        <input name="title" class="form-control" placeholder="Title" required>
    </div>

    <div class="col-md-3">
        <input name="description" class="form-control" placeholder="Description" required>
    </div>

    <div class="col-md-2">
        <input name="copies" type="number" class="form-control" placeholder="Copies" min="1" required>
    </div>

    <div class="col-md-2">
        <input name="year" type="number" class="form-control" placeholder="Year" required>
    </div>

    <!-- GENRES (MULTI SELECT) -->
    <div class="col-md-12">
        <label class="fw-bold">Genres (select multiple)</label><br>

        <label><input type="checkbox" name="genre" value="Action"> Action</label>
        <label><input type="checkbox" name="genre" value="Horror"> Horror</label>
        <label><input type="checkbox" name="genre" value="Thriller"> Thriller</label>
        <label><input type="checkbox" name="genre" value="Drama"> Drama</label>
        <label><input type="checkbox" name="genre" value="Comedy"> Comedy</label>
        <label><input type="checkbox" name="genre" value="Sci-Fi"> Sci-Fi</label>
        <label><input type="checkbox" name="genre" value="Romance"> Romance</label>
    </div>

    <!-- DURATION -->
    <div class="col-md-2">
        <input name="hours" type="number" class="form-control" placeholder="Hours" required>
    </div>

    <div class="col-md-2">
        <input name="minutes" type="number" class="form-control" placeholder="Minutes" required>
    </div>

    <!-- RATING -->
    <div class="col-md-2">
        <input name="rating" class="form-control" placeholder="PG-13" required>
    </div>

    <!-- CRITIC (STRICT 1-5) -->
    <div class="col-md-2">
        <input name="criticRating"
               type="number"
               step="0.1"
               min="1"
               max="5"
               class="form-control"
               placeholder="1–5"
               required>
    </div>

    <div class="col-md-12">
        <button class="btn btn-primary w-100">Add Movie</button>
    </div>

</form>
</div>

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Movie Collection</h5>
    <span class="text-muted small">${movies.size()} total</span>
</div>

<!-- MOVIES -->
<div class="row g-4">

<c:forEach var="m" items="${movies}">
<div class="col-md-4">

<div class="card movie-card p-3 h-100">

    <div class="movie-title">${m.title}</div>

    <div class="meta">
        ${m.year} • ${m.genre} • ${m.rating}
    </div>

    <div class="meta">
        ${m.duration} min • ⭐ ${m.criticRating}
    </div>

    <div class="movie-desc">${m.description}</div>

    <div class="mb-2">
        <span class="badge bg-secondary">${m.availableCopies} copies</span>
    </div>

    <!-- ⭐ ACTION BUTTONS RESTORED -->
    <div class="d-flex gap-2">

        <!-- CHECKOUT -->
        <form action="/finalproject278/checkout" method="post">
            <input type="hidden" name="movieId" value="${m.id}">
            <button class="btn btn-success btn-sm"
                    ${m.availableCopies == 0 ? 'disabled' : ''}>
                Checkout
            </button>
        </form>

        <!-- EDIT -->
        <form action="/finalproject278/editMoviePage" method="get">
            <input type="hidden" name="id" value="${m.id}">
            <button class="btn btn-warning btn-sm">
                Edit
            </button>
        </form>

        <!-- DELETE -->
        <form action="/finalproject278/deleteMovie" method="post"
              onsubmit="return confirm('Delete this movie?')">
            <input type="hidden" name="id" value="${m.id}">
            <button class="btn btn-danger btn-sm">
                Delete
            </button>
        </form>

    </div>

</div>

</div>
</c:forEach>

</div>

</div>