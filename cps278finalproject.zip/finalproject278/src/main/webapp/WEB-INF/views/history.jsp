<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="header.jsp" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<style>
    .timeline-card {
        border-left: 4px solid #dee2e6;
        transition: 0.2s;
    }

    .timeline-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 22px rgba(0,0,0,0.08);
    }

    .status-badge {
        font-size: 0.75rem;
        letter-spacing: 0.4px;
    }

    .timeline-date {
        font-size: 0.85rem;
        color: #6c757d;
    }

    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #6c757d;
    }
</style>

<div class="container mt-4">

<div class="card shadow-sm p-4 border-0">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Checkout History</h4>
        <span class="text-muted small">
            ${history.size()} records
        </span>
    </div>

    <!-- HISTORY LIST -->
    <c:forEach var="h" items="${history}">

    <div class="timeline-card bg-white rounded p-3 mb-3">

        <!-- TOP ROW -->
        <div class="d-flex justify-content-between align-items-center mb-2">

            <div class="fw-semibold">
                ${h.movie.title}
            </div>

            <span class="badge status-badge px-3 py-2 
                bg-${h.returned ? 'success' : 'warning'}">

                ${h.returned ? 'Returned' : 'Out'}

            </span>

        </div>

        <!-- DATES -->
        <div class="timeline-date mb-2">
            Checked out: ${h.checkoutDate}
        </div>

        <c:if test="${h.returned}">
            <div class="timeline-date mb-2">
                Returned: ${h.returnDate}
            </div>
        </c:if>

        <!-- ACTION -->
        <c:if test="${!h.returned}">
            <form action="/finalproject278/return" method="post">
                <input type="hidden" name="checkoutId" value="${h.id}">
                <button class="btn btn-sm btn-outline-primary rounded-3">
                    Return Movie
                </button>
            </form>
        </c:if>

    </div>

    </c:forEach>

    <!-- EMPTY STATE -->
    <c:if test="${empty history}">
        <div class="empty-state">
            <h6>No history yet</h6>
            <div class="small">Movies you check out will appear here</div>
        </div>
    </c:if>

</div>

</div>