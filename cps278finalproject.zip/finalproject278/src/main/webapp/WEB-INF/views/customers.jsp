<%@ page contentType="text/html; charset=UTF-8" %>
<%@ include file="header.jsp" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<div class="container mt-4">

<div class="card shadow-lg border-0 p-4 rounded-4">

<h3 class="mb-4 fw-bold">👤 Customer Management</h3>

<!-- ERROR (CLEAN MODERN STYLE) -->
<c:if test="${not empty error}">
    <div class="alert alert-warning d-flex align-items-center shadow-sm">
        <span class="me-2">⚠</span>
        <div>${error}</div>
    </div>
</c:if>

<!-- ADD CUSTOMER CARD -->
<div class="card border-0 shadow-sm mb-4">
<div class="card-body">

<form action="/finalproject278/addCustomer" method="post" class="row g-3">

    <div class="col-md-5">
        <label class="form-label small text-muted">Name</label>
        <input class="form-control"
               name="name"
               placeholder="Enter customer name"
               value="${nameValue}">
    </div>

    <div class="col-md-5">
        <label class="form-label small text-muted">Email</label>
        <input class="form-control"
               name="email"
               placeholder="name@gmail.com"
               value="${emailValue}">
    </div>

    <div class="col-md-2 d-flex align-items-end">
        <button class="btn btn-primary w-100 shadow-sm">
            + Add
        </button>
    </div>

</form>

</div>
</div>

<!-- TABLE -->
<div class="table-responsive">

<table class="table table-hover align-middle shadow-sm">

<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th class="text-center">Actions</th>
</tr>
</thead>

<tbody>

<c:forEach var="c" items="${customers}">
<tr>

<td class="fw-bold">${c.id}</td>

<td>
    <input type="text"
           value="${c.name}"
           form="form-${c.id}"
           name="name"
           class="form-control form-control-sm">
</td>

<td>
    <input type="text"
           value="${c.email}"
           form="form-${c.id}"
           name="email"
           class="form-control form-control-sm">
</td>

<td class="text-center">

    <form id="form-${c.id}"
          action="/finalproject278/updateCustomer"
          method="post"
          class="d-inline">
        <input type="hidden" name="id" value="${c.id}">
        <button class="btn btn-sm btn-outline-warning">
            Update
        </button>
    </form>

    <form action="/finalproject278/deleteCustomer"
          method="post"
          class="d-inline"
          onsubmit="return confirm('Delete this customer?')">
        <input type="hidden" name="id" value="${c.id}">
        <button class="btn btn-sm btn-outline-danger">
            Delete
        </button>
    </form>

</td>

</tr>
</c:forEach>

</tbody>
</table>

</div>

</div>
</div>