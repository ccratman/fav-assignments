<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="header.jsp" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<style>
    .edit-card {
        border: none;
        border-radius: 18px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }

    .section-title {
        font-size: 0.85rem;
        font-weight: 600;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 8px;
    }

    .genre-box {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 12px;
    }

    .genre-box label {
        margin-right: 12px;
        font-size: 0.9rem;
    }

    .form-control {
        border-radius: 10px;
    }

    .btn-save {
        border-radius: 12px;
        padding: 12px;
        font-weight: 600;
    }
</style>

<div class="container mt-4">

<c:if test="${not empty error}">
    <div class="alert alert-danger shadow-sm">
        ${error}
    </div>
</c:if>

<div class="card edit-card p-4">

    <h3 class="mb-4">Edit Movie</h3>

    <form action="/finalproject278/editMovie" method="post" class="row g-3">

        <input type="hidden" name="id" value="${movie.id}">

        <!-- TITLE -->
        <div class="col-md-6">
            <div class="section-title">Title</div>
            <input class="form-control" name="title" value="${movie.title}" required>
        </div>

        <!-- DESCRIPTION -->
        <div class="col-md-6">
            <div class="section-title">Description</div>
            <input class="form-control" name="description" value="${movie.description}" required>
        </div>

        <!-- COPIES (ALLOW 0 IN EDIT) -->
        <div class="col-md-3">
            <div class="section-title">Copies</div>
            <input class="form-control" type="number" name="copies"
                   value="${movie.availableCopies}" min="0" required>
        </div>

        <!-- YEAR -->
        <div class="col-md-3">
            <div class="section-title">Year</div>
            <input class="form-control" type="number" name="year"
                   value="${movie.year}" required>
        </div>

        <!-- GENRES -->
        <div class="col-12">
            <div class="section-title">Genres</div>
            <div class="genre-box">

                <label><input type="checkbox" name="genre" value="Action"
                    ${fn:contains(movie.genre, 'Action') ? 'checked' : ''}> Action</label>

                <label><input type="checkbox" name="genre" value="Horror"
                    ${fn:contains(movie.genre, 'Horror') ? 'checked' : ''}> Horror</label>

                <label><input type="checkbox" name="genre" value="Thriller"
                    ${fn:contains(movie.genre, 'Thriller') ? 'checked' : ''}> Thriller</label>

                <label><input type="checkbox" name="genre" value="Drama"
                    ${fn:contains(movie.genre, 'Drama') ? 'checked' : ''}> Drama</label>

                <label><input type="checkbox" name="genre" value="Comedy"
                    ${fn:contains(movie.genre, 'Comedy') ? 'checked' : ''}> Comedy</label>

                <label><input type="checkbox" name="genre" value="Sci-Fi"
                    ${fn:contains(movie.genre, 'Sci-Fi') ? 'checked' : ''}> Sci-Fi</label>

                <label><input type="checkbox" name="genre" value="Romance"
                    ${fn:contains(movie.genre, 'Romance') ? 'checked' : ''}> Romance</label>

            </div>
        </div>

        <!-- HOURS (FIXED DIV, NO DECIMAL ISSUES) -->
        <div class="col-md-3">
            <div class="section-title">Hours</div>
            <input class="form-control" type="number" name="hours"
                   value="${movie.duration div 60}" min="0" required>
        </div>

        <!-- MINUTES (SAFE CALC) -->
        <div class="col-md-3">
            <div class="section-title">Minutes</div>
            <input class="form-control" type="number" name="minutes"
                   value="${movie.duration - (movie.duration div 60) * 60}"
                   min="0" max="59" required>
        </div>

        <!-- RATING -->
        <div class="col-md-3">
            <div class="section-title">Rating</div>
            <input class="form-control" name="rating"
                   value="${movie.rating}" required>
        </div>

        <!-- CRITIC -->
        <div class="col-md-3">
            <div class="section-title">Critic Rating (1–5)</div>
            <input class="form-control"
                   type="number"
                   name="criticRating"
                   value="${movie.criticRating}"
                   min="1"
                   max="5"
                   step="0.1"
                   required>
        </div>

        <!-- BUTTON -->
        <div class="col-12 mt-2">
            <button class="btn btn-primary btn-save w-100">
                Save Changes
            </button>
        </div>

    </form>

</div>
</div>