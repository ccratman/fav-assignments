<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6fb;
        }

        .hero {
            background: linear-gradient(90deg, #1e1e2f, #2c2c54);
            color: white;
            border-radius: 18px;
        }

        .card {
            border-radius: 18px;
            border: none;
            transition: all 0.25s ease;
        }

        .card:hover {
            transform: translateY(-6px);
            box-shadow: 0 14px 30px rgba(0,0,0,0.12);
        }

        .btn-rounded {
            border-radius: 12px;
        }

        .subtle {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .emoji {
            font-size: 1.5rem;
        }

        .title {
            font-weight: 600;
        }

        .form-control {
            border-radius: 10px;
        }
    </style>
</head>

<body>

<%@ include file="header.jsp" %>

<div class="container mt-4">

    <!-- HERO -->
    <div class="hero shadow-sm p-4 mb-4">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

            <div>
                <h4 class="mb-1">
                    👋 Welcome back,
                    <strong>
                        <c:choose>
                            <c:when test="${not empty currentCustomer}">
                                ${currentCustomer.name}
                            </c:when>
                            <c:otherwise>
                                Guest
                            </c:otherwise>
                        </c:choose>
                    </strong>
                </h4>

                <div class="text-white-50 small">
                    🎬 Manage movies, checkout system, and history in one place
                </div>
            </div>

            <form action="/finalproject278/" method="get" class="d-flex gap-2">

                <select name="customerId" class="form-select">

                    <c:forEach var="c" items="${customers}">
                        <option value="${c.id}"
                            ${sessionScope.customerId == c.id ? 'selected' : ''}>
                            👤 ${c.name}
                        </option>
                    </c:forEach>

                </select>

                <button class="btn btn-light btn-rounded">
                    🔄 Switch
                </button>

            </form>

        </div>

    </div>

    <!-- CARDS -->
    <div class="row g-4">

        <!-- MOVIES -->
        <div class="col-md-4">
            <div class="card p-4 text-center h-100">

                <div class="emoji mb-2">🎬</div>
                <h5 class="title">Movies</h5>

                <p class="subtle">Browse, edit, delete, and manage inventory</p>

                <a href="/finalproject278/movies"
                   class="btn btn-primary btn-rounded w-100">
                    ▶ Open Movies
                </a>

            </div>
        </div>

        <!-- HISTORY -->
        <div class="col-md-4">
            <div class="card p-4 text-center h-100">

                <div class="emoji mb-2">📜</div>
                <h5 class="title">History</h5>

                <p class="subtle">Track checkouts and returns per customer</p>

                <a href="/finalproject278/history"
                   class="btn btn-success btn-rounded w-100">
                    📜 View History
                </a>

            </div>
        </div>

        <!-- ADD MOVIE (FIXED TO MATCH VALIDATION RULES) -->
        <div class="col-md-4">
            <div class="card p-4 h-100">

                <div class="text-center mb-2">
                    <span class="emoji">🎟️</span>
                    <h5 class="title">Quick Add Movie</h5>
                </div>

                <form action="/finalproject278/addMovie" method="post">

                    <input class="form-control mb-2" name="title" placeholder="🎞 Title" required>
                    <input class="form-control mb-2" name="description" placeholder="📝 Description" required>

                    <input class="form-control mb-2" name="copies" type="number" min="1" placeholder="📦 Copies" required>
                    <input class="form-control mb-2" name="year" type="number" placeholder="📅 Year" required>

                    <!-- GENRE WARNING -->
                    <input class="form-control mb-2"
                           name="genre"
                           placeholder="🎭 Genres (comma separated: Action,Horror)"
                           required>

                    <!-- DURATION -->
                    <div class="d-flex gap-2 mb-2">
                        <input class="form-control" name="hours" type="number" placeholder="⏱ Hours" required>
                        <input class="form-control" name="minutes" type="number" placeholder="⏱ Min" required>
                    </div>

                    <input class="form-control mb-2" name="rating" placeholder="🔞 PG-13 / R" required>

                    <input class="form-control mb-3"
                           name="criticRating"
                           type="number"
                           min="1"
                           max="5"
                           step="0.1"
                           placeholder="⭐ Critic (1–5)"
                           required>

                    <button class="btn btn-warning btn-rounded w-100">
                        ➕ Add Movie
                    </button>

                </form>

                <div class="small text-muted mt-2">
                    ⚠ All fields required
                </div>

            </div>
        </div>

    </div>

</div>

</body>
</html>