package com.example.budgetapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Mint primary brand color
val Mint = Color(0xFF4BE3C1)
val MintDark = Color(0xFF26BFA1)
val MintLight = Color(0xFFB2FFF0)

// Rocket-style deep navy backgrounds
val RocketBlack = Color(0xFF0D0F14)
val RocketNavy = Color(0xFF1B1E27)
val RocketCard = Color(0xFF242832)

// Accent (charts, important highlights)
val NeonBlue = Color(0xFF4FC3F7)
val NeonPurple = Color(0xFFB388FF)
val NeonRed = Color(0xFFFF5252)
val NeonYellow = Color(0xFFFFEB3B)

// Text
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFBFC2C8)

// Light mode backgrounds
val LightBackground = Color(0xFFF8FFFD)
val LightCard = Color(0xFFFFFFFF)