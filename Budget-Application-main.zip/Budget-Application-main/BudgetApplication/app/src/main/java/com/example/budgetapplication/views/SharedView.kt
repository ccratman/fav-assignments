package com.example.budgetapplication.views

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.budgetapplication.data.database.AppDatabase
import com.example.budgetapplication.data.repository.LoginRepository

class SharedView: ViewModel() {
        var currentUser: String by mutableStateOf("Scott")
            private set
        fun updateUser(user: String) {
            currentUser = user
        }

        fun clearUser() {
            currentUser = ""
        }
}








//        companion object {
//            fun provideFactory(application: Application): ViewModelProvider.Factory {
//                // Create a NoteRepository, which in turn depends on NoteDao from NoteDatabase.
//                return SharedViewModelFactory(
//                    LoginRepository(
//                        userDAO = AppDatabase.getDatabase(application).userDAO()
//                    )
//                )
//            }
//        }
//    }
//
//
//class SharedViewModelFactory(private val repository: LoginRepository) : ViewModelProvider.Factory {
//    override fun <T : ViewModel> create(modelClass: Class<T>): T {
//        if (modelClass.isAssignableFrom(LazyCardView::class.java)) {
//            @Suppress("UNCHECKED_CAST")
//            return SharedView(repository) as T
//        }
//        throw IllegalArgumentException("Unknown ViewModel class")
//    }
//}


