package com.example.budgetapplication.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Typography = Typography(
    displayLarge = TextStyle( // For big headings like "Welcome!"
        fontFamily = FontFamily.Default,
        fontSize = 42.sp,
        fontWeight = FontWeight.Bold
    ),
    titleLarge = TextStyle( // For summary card titles
        fontFamily = FontFamily.Default,
        fontSize = 22.sp,
        fontWeight = FontWeight.SemiBold
    ),
    bodyLarge = TextStyle( // For normal body text
        fontFamily = FontFamily.Default,
        fontSize = 18.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 24.sp
    ),
    labelLarge = TextStyle( // For buttons or labels
        fontFamily = FontFamily.Default,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium
    ),
    headlineMedium = TextStyle( // Subheadings, e.g., "Here's your spending overview"
        fontFamily = FontFamily.Default,
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold
    )
)
