package com.example.budgetapplication.views

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.budgetapplication.data.database.AppDatabase
import com.example.budgetapplication.data.entities.Category
import com.example.budgetapplication.data.entities.Item
import com.example.budgetapplication.data.entities.Merchant
import com.example.budgetapplication.data.entities.Receipt
import com.example.budgetapplication.data.repository.LazyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.Int

class LazyCardView(private val repository: LazyRepository) : ViewModel() {

//animations for adding category
    var expanded by  mutableStateOf(false)
    var showDetails by mutableStateOf(false)
        private val _spendingMap = mutableStateMapOf<Int, Double>()
        val spendingMap: Map<Int, Double> get() = _spendingMap

    suspend fun getCurrentSpending(categoryId: Int?) {
        if (categoryId == null) return

        val spending = repository.getCurrentSpending(categoryId) ?: 0.0

        _spendingMap[categoryId] = spending
    }


    fun getItemsForCategory(categoryId: Int?): Flow<List<Item>> {
        return repository.getItemsByCategory(categoryId)
            .flowOn(Dispatchers.IO) // run query in background
    }



    //*
    // Create Budget Screen Logic
    // */
    var budgetLimit_s by mutableStateOf("")
        private set
    var budgetStart_s by mutableStateOf("")
        private set
    var budgetEnd_s by mutableStateOf("")
        private set
    var categoryLimit_s by mutableStateOf("")
    var categoryName_s by mutableStateOf("")

    var newestCategory : Category = Category()

    fun buildCategory(){
        newestCategory.categoryName_s = categoryName_s
        newestCategory.categoryLimit_s = categoryLimit_s
        newestCategory.categoryOut_b = false
        newestCategory.budgetId_i = 4

    }

     fun createNewCategory(){
        viewModelScope.launch {
            repository.createNewCategory(newestCategory)
        }
    }
    fun changeBudgetLimit(newLimit : String) {
        budgetLimit_s = newLimit
    }
    fun changeCategoryLimit(newLimit : String) {
        categoryLimit_s = newLimit
    }
    fun changeCategoryName(newName : String) {
        categoryName_s = newName
    }
    fun changeStart(newStart : String) {
        budgetStart_s = newStart
    }

    fun changeEnd(newEnd : String) {
        budgetEnd_s = newEnd
    }
    //*
    // Create Budget Screen Logic
    // */



    //*
    // Create View Screen Logic
    // *
    var selectedTabIndex by mutableStateOf(0)
    val tabs = listOf("Receipts", "Items", "Items by Category")
    var selectedReceipt by mutableStateOf<Int?>(null)
    val receipts: StateFlow<List<Receipt>> = repository.AllReceipts.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000), // Start collecting when there's an active subscriber and stop 5s after the last subscriber disappears.
        emptyList()
    )
    val categories: StateFlow<List<Category>> = repository.AllCategories.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000), // Start collecting when there's an active subscriber and stop 5s after the last subscriber disappears.
        emptyList()
    )


    // Line items for the selected receipt, automatically updates when selectedReceipt changes
    @OptIn(ExperimentalCoroutinesApi::class)
    val lineItemsPerReceipt: StateFlow<List<Item>> = snapshotFlow { selectedReceipt }
        .flatMapLatest { id -> repository.getItemsForReceipt(id) }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    @OptIn(ExperimentalCoroutinesApi::class)
    val lineItems: StateFlow<List<Item>> = repository.AllLineItems
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    var merchants = mutableStateMapOf<Int, Merchant>()
        private set
    fun loadMerchant(id: Int?) {
        viewModelScope.launch {
            val currentMerchant = repository.getMerchantById(id)
            if (id!= null)
            merchants.put(id, currentMerchant)
        }
    }
    var listItems by mutableStateOf(false)







    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            // Create a NoteRepository, which in turn depends on NoteDao from NoteDatabase.
            return NoteViewModelFactory(LazyRepository(
                receiptDAO = AppDatabase.getDatabase(application).receiptDAO(),
                merchantDAO = AppDatabase.getDatabase(application).merchantDAO(),
                itemDAO = AppDatabase.getDatabase(application).itemDAO(),
                categoryDAO = AppDatabase.getDatabase(application).categoryDAO(),
                budgetDAO = AppDatabase.getDatabase(application).budgetDAO()

            ))
        }
    }
}


class NoteViewModelFactory(private val repository: LazyRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LazyCardView::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LazyCardView(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}








