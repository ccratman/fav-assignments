package com.example.budgetapplication.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Mint,
    secondary = MintDark,
    background = LightBackground,
    surface = LightCard,
    onPrimary = Color.Black,
    onBackground = Color.Black
)

private val DarkColors = darkColorScheme(
    primary = Mint,
    secondary = MintLight,
    background = RocketBlack,
    surface = RocketCard,
    onPrimary = TextWhite,
    onBackground = TextWhite
)

@Composable
fun BudgetApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}

