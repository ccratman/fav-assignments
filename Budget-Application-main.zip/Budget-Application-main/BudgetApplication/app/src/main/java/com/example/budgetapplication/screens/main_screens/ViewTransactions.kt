package com.example.budgetapplication.screens.main_screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.budgetapplication.ui.theme.Mint
import com.example.budgetapplication.ui.theme.RocketCard
import com.example.budgetapplication.views.LazyCardView
import com.example.budgetapplication.views.SharedView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewTransactions(
    onProfileClick: () -> Unit,
    onBackClick: () -> Unit,
    onHomeClick: (String) -> Unit,
    onInputSpendingClick: () -> Unit,
    onViewTransactionClick: () -> Unit,
    sharedView: SharedView,
    lazyCardView: LazyCardView
) {
    val receipts by lazyCardView.receipts.collectAsState()
    val lineItems by lazyCardView.lineItemsPerReceipt.collectAsState()
    Scaffold(topBar = {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Mint, titleContentColor = RocketCard
            ),
            title = {
                Text("View Receipts" )
            },

        )
    },
        bottomBar = {
            NavBar(
                onSettingsClick = { onProfileClick() },
                onHomeClick = { onHomeClick("") },
                onInputSpendingClick = { onInputSpendingClick() },
                onViewTransactionClick = { onViewTransactionClick() },
            )
        }) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),

            ) {
            PrimaryTabRow(selectedTabIndex = lazyCardView.selectedTabIndex, modifier = Modifier) {
                lazyCardView.tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = lazyCardView.selectedTabIndex == index,
                        onClick = { lazyCardView.selectedTabIndex = index },
                        text = { Text(title) })

                }
            }

            when (lazyCardView.selectedTabIndex) {
                0 -> ViewReceipts(lazyCardView)
                1 -> ViewItems(lazyCardView)
                2 -> CategoryItems(lazyCardView)
            }

        }

    }
}
    @Composable
    fun ViewItems(lazyCardView: LazyCardView) {
        val lineItems by lazyCardView.lineItems.collectAsState()
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items = lineItems ) { item ->
                LazyCard(item)
            }

        }
    }



@Composable
fun ViewReceipts(lazyCardView: LazyCardView) {
    val receipts by lazyCardView.receipts.collectAsState()
    val lineItems by lazyCardView.lineItemsPerReceipt.collectAsState()
    if (!lazyCardView.listItems) {

        Column {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items = receipts) { item ->
                    lazyCardView.loadMerchant(item.merchantId_i)
                    LazyCard(receipt = item, onItemClick = {
                        lazyCardView.listItems = !lazyCardView.listItems
                        lazyCardView.selectedReceipt = item.receiptId_i
                    })
                }
            }
        }
    } else {
        Column {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items = lineItems) { item ->
                    LazyCard(item)
                }
                item {
                    Button({
                        lazyCardView.listItems = !lazyCardView.listItems
                    }) { Text("Back") }
                }
            }
        }
    }

}










