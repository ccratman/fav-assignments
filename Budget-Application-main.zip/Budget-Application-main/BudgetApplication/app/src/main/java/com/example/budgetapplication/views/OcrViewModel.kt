package com.example.budgetapplication.views

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class OcrViewModel(application: Application) : AndroidViewModel(application) {

    var jsonResult: String? = null
    var isLoading = false
    var errorMessage: String? = null

    private val TABSCANNER_API_KEY = "LbHhjnDlhKYchhVnpEek62UlndJqzzyL9HlTFUGbkKumccHNxQAb5c8xJmUY7z1n"

    // Convert URI → File
    fun uriToFile(uri: Uri): File {
        val resolver: ContentResolver = getApplication<Application>().contentResolver
        val inputStream = resolver.openInputStream(uri)
        val tempFile = File.createTempFile("receipt_", ".jpg", getApplication<Application>().cacheDir)
        FileOutputStream(tempFile).use { output ->
            inputStream?.copyTo(output)
        }
        return tempFile
    }

    // Process multiple files (new method for OCR screen)
    fun processFiles(files: List<File>, onDone: (mergedJson: String?, error: String?) -> Unit) {
        isLoading = true
        errorMessage = null
        jsonResult = null

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val results = mutableListOf<String>()
                for (file in files) {
                    val result = uploadAndPollTabscanner(file)
                    if (result != null) {
                        results.add(result)
                        Log.d("OcrViewModel", "File processed successfully, result length: ${result.length}")
                    } else {
                        throw Exception("Failed to process file: ${file.name}")
                    }
                }

                // Merge results if multiple files
                val merged = if (results.size > 1) {
                    mergeTabscannerResults(results)
                } else {
                    results.firstOrNull() ?: "{}"
                }

                Log.d("OcrViewModel", "Final merged JSON: $merged")
                jsonResult = merged
                errorMessage = null
                isLoading = false
                withContext(Dispatchers.Main) { onDone(merged, null) }

            } catch (e: Exception) {
                Log.e("OcrViewModel", "processFiles error: ${e.message}", e)
                isLoading = false
                errorMessage = e.localizedMessage ?: "Unknown error"
                withContext(Dispatchers.Main) { onDone(null, errorMessage) }
            }
        }
    }

    // Upload and poll a single file
    private suspend fun uploadAndPollTabscanner(file: File): String? = withContext(Dispatchers.IO) {
        try {
            val token = uploadToTabscanner(file) ?: return@withContext null
            return@withContext pollTabscannerForResult(token)
        } catch (e: Exception) {
            null
        }
    }

    // Upload image to Tabscanner
    private suspend fun uploadToTabscanner(file: File): String? = withContext(Dispatchers.IO) {
        try {
            Log.d("OcrViewModel", "Uploading file: ${file.name} (${file.length()} bytes)")
            val client = OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "file",
                    file.name,
                    RequestBody.create("image/jpeg".toMediaTypeOrNull(), file)
                )
                .build()

            val request = Request.Builder()
                .url("https://api.tabscanner.com/api/2/process")
                .addHeader("apikey", TABSCANNER_API_KEY)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val bodyString = response.body?.string()

            Log.d("OcrViewModel", "Upload response code: ${response.code}")
            Log.d("OcrViewModel", "Upload response: $bodyString")

            if (!response.isSuccessful) {
                Log.e("OcrViewModel", "Upload failed with code ${response.code}: $bodyString")
                return@withContext null
            }

            val json = JSONObject(bodyString ?: "{}")
            val token = json.optString("token").ifEmpty { json.optString("id", "") }
            Log.d("OcrViewModel", "Token received: $token")
            token.ifEmpty { null }
        } catch (e: Exception) {
            Log.e("OcrViewModel", "Upload error", e)
            null
        }
    }

    // Poll Tabscanner with exponential backoff
    private suspend fun pollTabscannerForResult(sessionId: String, maxAttempts: Int = 6, delayMs: Long = 2000): String? = withContext(Dispatchers.IO) {
        try {
            var delay = delayMs
            for (attempt in 0 until maxAttempts) {
                Log.d("OcrViewModel", "Poll attempt $attempt, waiting ${delay}ms for session: $sessionId")
                kotlinx.coroutines.delay(delay)

                val client = OkHttpClient.Builder()
                    .readTimeout(60, TimeUnit.SECONDS)
                    .build()

                val request = Request.Builder()
                    .url("https://api.tabscanner.com/api/result/$sessionId")
                    .addHeader("apikey", TABSCANNER_API_KEY)
                    .get()
                    .build()

                val response = client.newCall(request).execute()
                val bodyString = response.body?.string()

                Log.d("OcrViewModel", "Poll response code: ${response.code}, body: $bodyString")

                val json = JSONObject(bodyString ?: "{}")
                val processing = json.optBoolean("processing", false)
                val statusCode = json.optInt("status_code", -1)

                Log.d("OcrViewModel", "Status - processing: $processing, statusCode: $statusCode")

                if (!processing && statusCode == 3) {
                    Log.d("OcrViewModel", "Processing complete!")
                    return@withContext json.toString()
                }

                delay *= 2  // Exponential backoff
            }
            Log.e("OcrViewModel", "Polling timeout after $maxAttempts attempts")
            null
        } catch (e: Exception) {
            Log.e("OcrViewModel", "Poll error", e)
            null
        }
    }

    // Merge multiple receipt results
    private fun mergeTabscannerResults(results: List<String>): String {
        var merchant = ""
        var date = ""
        var subtotalSum = 0.0
        var taxSum = 0.0
        var totalSum = 0.0
        val mergedLineItems = JSONArray()

        for (rawResult in results) {
            try {
                val root = JSONObject(rawResult)
                val result = root.optJSONObject("result") ?: continue

                if (merchant.isBlank()) {
                    merchant = result.optString("establishment", "")
                }
                if (date.isBlank()) {
                    date = result.optString("date", "")
                }

                subtotalSum += result.optDouble("subTotal", 0.0)
                taxSum += result.optDouble("tax", 0.0)
                totalSum += result.optDouble("total", 0.0)

                val items = result.optJSONArray("lineItems")
                if (items != null) {
                    for (i in 0 until items.length()) {
                        mergedLineItems.put(items.getJSONObject(i))
                    }
                }
            } catch (e: Exception) {
                // Ignore parse errors for individual results
            }
        }

        val mergedResult = JSONObject().apply {
            put("establishment", merchant)
            put("date", date)
            put("subTotal", subtotalSum)
            put("tax", taxSum)
            put("total", totalSum)
            put("lineItems", mergedLineItems)
        }

        return JSONObject().apply {
            put("message", "MERGED_SUCCESS")
            put("status", "done")
            put("status_code", 3)
            put("result", mergedResult)
        }.toString()
    }
}