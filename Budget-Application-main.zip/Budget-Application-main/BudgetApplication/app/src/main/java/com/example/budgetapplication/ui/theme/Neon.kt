package com.example.budgetapplication.ui.theme

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.BlurEffect

fun Modifier.neonGlow(
    glowColor: Color = Color(0xFF00FFAA), // mint glow
    radius: Float = 40f
): Modifier = this.then(
    Modifier.drawBehind {
        drawIntoCanvas { canvas ->

            // Compose Paint that supports blur (NO nativeCanvas needed)
            val paint = Paint().apply {
                this.color = glowColor
                this.asFrameworkPaint().apply {
                    isAntiAlias = true
                    maskFilter = android.graphics.BlurMaskFilter(radius, android.graphics.BlurMaskFilter.Blur.NORMAL)
                }
            }

            // Draw glowing rectangle
            canvas.drawRect(0f, 0f, size.width, size.height, paint)
        }
    }
)
